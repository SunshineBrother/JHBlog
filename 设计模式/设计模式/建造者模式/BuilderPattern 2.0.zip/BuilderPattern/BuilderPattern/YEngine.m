//
//  YEngine.m
//  BuilderPattern
//
//  Created by YouXianMing on 15/10/18.
//  Copyright © 2015年 YouXianMing. All rights reserved.
//

#import "YEngine.h"

@implementation YEngine

- (void)engineScale:(CGFloat)scale {
    
    // todo
}

- (void)engineWeight:(CGFloat)kg {
    
    // todo
}

- (NSString *)infomation {
    
    return @"Y-Engine, scale : 20, weight : 58";
}

- (id)build {
    
    // todo
    
    return nil;
}

@end
