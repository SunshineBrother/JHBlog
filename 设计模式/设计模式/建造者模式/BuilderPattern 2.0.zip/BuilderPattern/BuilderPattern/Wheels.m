//
//  Wheels.m
//  BuilderPattern
//
//  Created by YouXianMing on 15/10/18.
//  Copyright © 2015年 YouXianMing. All rights reserved.
//

#import "Wheels.h"

@implementation Wheels

- (void)wheelsNumber:(NSNumber *)number {

    // todo
}

- (NSString *)infomation {

    return @"X1-wheels, number : 4";
}

- (id)build {
    
    // todo
    
    return nil;
}

@end
