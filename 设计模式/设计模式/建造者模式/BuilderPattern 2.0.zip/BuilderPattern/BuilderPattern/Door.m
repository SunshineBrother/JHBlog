//
//  Door.m
//  BuilderPattern
//
//  Created by YouXianMing on 15/10/18.
//  Copyright © 2015年 YouXianMing. All rights reserved.
//

#import "Door.h"

@implementation Door

- (void)doorColor:(UIColor *)color {

    // todo
}

- (NSString *)infomation {

    return @"X1-door, color : red";
}

- (id)build {
    
    // todo
    
    return nil;
}

@end
