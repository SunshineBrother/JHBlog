//
//  Engine.m
//  BuilderPattern
//
//  Created by YouXianMing on 15/10/18.
//  Copyright © 2015年 YouXianMing. All rights reserved.
//

#import "Engine.h"

@implementation Engine

- (void)engineScale:(CGFloat)scale {

    // todo
}

- (void)engineWeight:(CGFloat)kg {

    // todo
}

- (NSString *)infomation {

    return @"X1-Engine, scale : 10, weight : 100";
}

- (id)build {

    // todo
    
    return nil;
}

@end
